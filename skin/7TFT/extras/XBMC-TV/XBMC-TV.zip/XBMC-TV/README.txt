XBMC-TV - Your source for Broadband (200k+) LIVE video streams on XBMC

Team Members:

- Akaigotchi
- MikeSyr
- Piranna
- ElenionTolto (timdog82001)
- Muuminpapa
- Vanadium
- QuazarXpress
- Direttissimer
- Cirusdervirus
- Chi3f

Find updates at http://www.xbmc-tv.com or in the official SVN at http://xbmc-strm-collection.googlecode.com/svn/trunk/

(tortoiseSVN (or any other SVN client) is needed to obtain SVN - http://tortoisesvn.net/downloads)

~~~~~~~
NOTICE: If you feel that any webstream/channel is missing in this collection or if you have any other questions concerning XBMC-TV please do not hesitate to contact the team via xbmctv@gmail.com .